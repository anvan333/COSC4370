/*******************************************************
 * Homework 2: OpenGL                                  *
 *-----------------------------------------------------*
 * First, you should fill in problem1(), problem2(),   *
 * and problem3() as instructed in the written part of *
 * the problem set.  Then, express your creativity     *
 * with problem4()!                                    *
 *                                                     *
 * Note: you will only need to add/modify code where   *
 * it says "TODO".                                     *
 *                                                     *
 * The left mouse button rotates, the right mouse      *
 * button zooms, and the keyboard controls which       *
 * problem to display.                                 *
 *                                                     *
 * For Linux/OS X:                                     *
 * To compile your program, just type "make" at the    *
 * command line.  Typing "make clean" will remove all  *
 * computer-generated files.  Run by typing "./hw2"    *
 *                                                     *
 * For Visual Studio:                                  *
 * You can create a project with this main.cpp and     *
 * build and run the executable as you normally would. *
 *******************************************************/

#include <iostream>
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "./freeglut-3.2.1/include/GL/freeglut.h"

using namespace std;

bool leftDown = false, rightDown = false;
int lastPos[2];
float cameraPos[4] = {0,1,4,1};
int windowWidth = 640, windowHeight = 480;
double yRot = 0;
int curProblem = 1; // TODO: change this number to try different examples

float specular[] = { 1.0, 1.0, 1.0, 1.0 };
float shininess[] = { 50.0 };

void problem1() {
    float x, y, angle1;
    int  angle2;
    angle1 = M_PI/5;
    angle2 = 36;
    glMatrixMode(GL_MODELVIEW);

    glPushMatrix();

    glTranslatef(2, 0, 0); //move teapot to first position
    glutSolidTeapot(.5); // draw

    glPopMatrix(); //bring back to origin


for (int n = 0; n < 9; n++ ) //loop to draw all teapots
{

  glPushMatrix(); 

  x = 2 * cos(angle1); //initialize x and y axis for rotation
  y = 2 * sin(angle1);

// moving the teapot
  glTranslatef(x, y, 0);
  glRotatef (angle2, 0, 0, 1);
  glutSolidTeapot(.5);
  glPopMatrix();

//create following rotation angle
  angle1 = angle1 + (M_PI/5);
  angle2 = angle2 + 36;

}


    /* flush drawing routines to the window */
    glFlush();
}

void problem2() {
  float trans, scale, num, temp;
  temp = .1;
  scale = 1;
  num = 0.2;
  trans = num/4;
/* clear window */

    //glClear(GL_COLOR_BUFFER_BIT);

    // original
    //glutSolidCube(.5);
glMatrixMode(GL_MODELVIEW);
for(float x = -3.5; x < 3.5; x += 0.5) //x axis in visible range
{

  glPushMatrix(); //start matrix
  glScalef(1, scale , 1); //make y taller
  glTranslatef(x, num/(5+temp), 0); //move x and y to make bottom flat
  glutSolidCube(.5); //draw
  glPopMatrix(); //bring back to origin

  temp += .25; // use to make sure y is flat
  num = num + 0.1; 

  scale = scale * 1.11; //scale beign mult to slowly exponentially grow taller
  


}
    /* flush drawing routines to the window */
    glFlush();
}

void problem3() {
    float x, y;
    x = 1;
    y = -1;

    /* clear window */
    //glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    /* draw scene */
    
    //draw first teapot
    glTranslatef(0, 4, 0);
    glutSolidTeapot(.5);
    //first loop for outer  teapots
    for (int m = 1; m < 6; m++)
    {
    //makes right side teapots
    glPushMatrix();
    glTranslatef(x* m, y* m, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    //makes left side teapots
    glPushMatrix();
    glTranslatef(-x* m, y* m, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    }
//draw 2nd y axis teapot
    glTranslatef(0, -2, 0);
    glutSolidTeapot(.5);
 //first layer loop for inner teapots
    for (int m = 1; m < 4; m++)
    {
    glPushMatrix();
    glTranslatef(x* m, y* m, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    //makes left side teapots
    glPushMatrix();
    glTranslatef(-x* m, y* m, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    }
//draw 3rd y axis teapot
    glTranslatef(0, -2, 0);
    glutSolidTeapot(.5);
    //make last two teapots
    
    glPushMatrix();
    glTranslatef(x, y, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    //makes left side teapot
    glPushMatrix();
    glTranslatef(-x, y, 0);
    glutSolidTeapot(.5);
    glPopMatrix();
    
    
    /* flush drawing routines to the window */
    glFlush();
}

void problem4() {
  for(float x = -10; x < 10; x += 0.5) //x axis in visible range
{
  glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(0, 3, 0);
    glScalef(1, .5 , 1); //move teapot to first position
    glutSolidTeapot(1.5); // draw
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0, 1, 0);
    glScalef(-10, 1 , 1);
    glutSolidCube(2);
    glPopMatrix();    

    glPushMatrix();
    glTranslatef(0, 1, 0);
     glScalef(-7, 1 , 1);
     glRotatef(180,1,0,0);
     glBegin(GL_TRIANGLES);
      glVertex2f(0.0f, 3.0f); 
     glVertex2f(5.2f,  -3.5f); 
      glVertex2f(-5.2f, -3.5f);
glEnd();
glPopMatrix(); 
  
  glPushMatrix();  // the conelike structure represents bottom of cup
    glTranslatef(6, 3.2, 0);
    glScalef(-1, 1 , 1);          
    glRotatef(90,1,0,0);
    glutSolidCone(1,1,8,4);
  glPopMatrix(); 

  glPushMatrix();
    glTranslatef(-6, 3.2, 0);
    glScalef(-1, 1 , 1);          
    glRotatef(90,1,0,0);
    glutSolidCone(1,1,8,4);
  glPopMatrix();


  glPushMatrix();   //the cube like cups represent teacups
    glTranslatef(6, 4, 0);
    glScalef(-1, 1 , 1);
    glutSolidCube(1.5);
      
  glPushMatrix();
    glTranslatef(12, 0, 0);
    glScalef(-1, 1 , 1);
    glutSolidCube(1.5);
  glPopMatrix(); 
 
  glPopMatrix(); 
 
}
}

void display() {
	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glDisable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glBegin(GL_LINES);
		glColor3f(1,0,0); glVertex3f(0,0,0); glVertex3f(1,0,0); // x axis
		glColor3f(0,1,0); glVertex3f(0,0,0); glVertex3f(0,1,0); // y axis
		glColor3f(0,0,1); glVertex3f(0,0,0); glVertex3f(0,0,1); // z axis
	glEnd(/*GL_LINES*/);

	glEnable(GL_LIGHTING);
	glShadeModel(GL_SMOOTH);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
	glEnable(GL_LIGHT0);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0,0,windowWidth,windowHeight);

	float ratio = (float)windowWidth / (float)windowHeight;
	gluPerspective(50, ratio, 1, 1000);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2], 0, 0, 0, 0, 1, 0);

	glLightfv(GL_LIGHT0, GL_POSITION, cameraPos);

	glRotatef(yRot,0,1,0);

	if (curProblem == 1) problem1();
	if (curProblem == 2) problem2();
	if (curProblem == 3) problem3();
	if (curProblem == 4) problem4();

	glutSwapBuffers();
}

void mouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) leftDown = (state == GLUT_DOWN);
	else if (button == GLUT_RIGHT_BUTTON) rightDown = (state == GLUT_DOWN);

	lastPos[0] = x;
	lastPos[1] = y;
}

void mouseMoved(int x, int y) {
	if (leftDown) yRot += (x - lastPos[0])*.1;
	if (rightDown) {
		for (int i = 0; i < 3; i++)
			cameraPos[i] *= pow(1.1,(y-lastPos[1])*.1);
	}


	lastPos[0] = x;
	lastPos[1] = y;
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
	curProblem = key-'0';
    if (key == 'q' || key == 'Q' || key == 27){
        exit(0);
    }
	glutPostRedisplay();
}

void reshape(int width, int height) {
	windowWidth = width;
	windowHeight = height;
	glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(windowWidth, windowHeight);
	glutCreateWindow("HW2");

	glutDisplayFunc(display);
	glutMotionFunc(mouseMoved);
	glutMouseFunc(mouse);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	glutMainLoop();

	return 0;
}
