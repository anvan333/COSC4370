#include <iostream>
#include "BMP.h"
#include <cmath>


int main() {
  
BMP bmpNew(1600,800,false);
 bmpNew.fill_region(0, 0, 200,200, 0, 0, 0, 0);

for(double x=-800; x<bmpNew.bmp_info_header.width;x++) 
{
  for(double y=0;y<bmpNew.bmp_info_header.height;y++)
        
          {
        for(double y=0;y<bmpNew.bmp_info_header.height;y++)
        {
          if (pow(x/12, 2) + pow(y/6, 2) <= pow(64.4, 2) && pow(x/12, 2) + pow(y/6, 2) >= pow(63.6, 2))
          {
            //std::cout << x << "," << y << "\n";
            bmpNew.set_pixel(x+800, y+400, 255, 255, 255, 0);
          }
      
     
        }
    }
    bmpNew.write("output.bmp");
}
}


